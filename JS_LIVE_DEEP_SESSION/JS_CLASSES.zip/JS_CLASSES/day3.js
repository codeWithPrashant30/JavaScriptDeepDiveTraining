console.log("Day 3");

// //datatype

// let obj1 ={
//     name:"Prashant",
//     age:30
// }
// let obj2 = {
//     name:"XyZ",
//     age:30
// }
// obj1 = obj2;
// console.log(obj1)

// console.log(obj1.name) //xyz

// Arithmetic Operators

let x = 20;
let y = 5;
let z = 3

// console.log(x+y)
// console.log(x-y)
// console.log(x*y)
// console.log(x/y);
// console.log(x%z);// modular // reminder
// console.log(x**y);
x++ //21
x-- //20
console.log(x); //20

// Assignment Operators
x += 4;
x-=4

x*=100;
x/=100;
x%=3;
x**=2
console.log(x);

//3️ Comparison Operators
// ===	Strict equality (no type conversion)
// !=	Loose not equal
// !==	Strict not equal
// >	Greater than
// <	Less than
// >=	Greater or equal
// <=	Less or equal

let a = 5;
let b = 7;
let c = 9;

// if(a<=b){
//     console.log("true")
// } else {
//     console.log("false")
// }

//logical operator

//&& all value should be true 

// if(a<b && a>c ){
//     console.log("true")
// } else {
//     console.log("false")
// }
// if(a<b || a>c ){
//     console.log("true")
// } else {
//     console.log("false")
// }


if(a!=b){
    console.log("true")
} else {
    console.log("false")
}





















