console.log("Hello Js Deep dive  Class 2");
// var x = 20;
// console.log(window.x); // undefined

// BUT objects & arrays CAN be modified

// const obj = { name: "A" };

// obj.name = "B";  // ✔ Allowed

// const arr = [1, 2];
// arr.push(3);     // ✔ Allowed
//  //Data Type 

// let str = "Hello";
// console.log(str[2])
// str[0] = "Y";   //  Not allowed
// str = " Hello My Frined"
// console.log(str); // "Hello"

// let x  = 5;
// let x  = "Hello";
// let x = true;
// console.log(typeof x)

// let x  = null;
// console.log(typeof x);   // undefined

// let id1 = Symbol("id");
// let id2 = Symbol("id");

// console.log(id1 === id2); // false (always unique)

// 

// console.log(c);
// const c = 30;

// var x = 10;
// {
//   let x = 20;
// }
// console.log(x);

// console.log(a);
// let a = 10;
// var b = 20;
// console.log(b);



