console.log("Hello Js Deep dive  Class 1");

// console.log(x) // undefined

// var x = "Hello";
// console.log(x)

// var name1 = "vaibhav"; //outdated before es6
// var name1  ="vaibhav 2" // global scope or function scope

// let name2 = "@codeWithPrashant30";
// name2 = "@codeWithPrashant302333"; // block scope

// const name3 = "chanchal"
// name3 = "chanchal2" // block scope


// {
//     var a = 10 ;
//     console.log("inside", a)
// }

//  console.log("outside", a)

// console.log("name1", name1)
// console.log("name2", name2)
// console.log("name3", name3)


